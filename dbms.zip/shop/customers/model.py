from shop import db, login_manager
from datetime import datetime
from flask_login import UserMixin
import json

@login_manager.user_loader
def user_loader(user_id):
    return Register.query.get(user_id)

class Register(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key= True)
    name = db.Column(db.String(50), unique= False)
    username = db.Column(db.String(50), unique= True)
    email = db.Column(db.String(50), unique= True)
    password = db.Column(db.String(200), unique= False)
    country = db.Column(db.String(50), unique= False)
    discount = db.Column(db.Integer,nullable=True)
    # coupon = db.Column(db.String(30),nullable=True)
    # state = db.Column(db.String(50), unique= False)
    city = db.Column(db.String(50), unique= False)
    contact = db.Column(db.String(50), unique= True)
    address = db.Column(db.String(50), unique= False)
    zipcode = db.Column(db.String(50), unique= False)
    profile = db.Column(db.String(200), unique= False , default='profile.jpg')
    date_created = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    def __repr__(self):
        return '<Register %r>' % self.name


class JsonEcodedDict(db.TypeDecorator):
    impl = db.Text
    def process_bind_param(self, value, dialect):
        if value is None:
            return '{}'
        else:
            return json.dumps(value)
    def process_result_value(self, value, dialect):
        if value is None:
            return {}
        else:
            return json.loads(value)

class CustomerOrder(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    invoice = db.Column(db.String(20), unique=True, nullable=False)
    status = db.Column(db.String(20), default='Success', nullable=False)
    customer_id = db.Column(db.Integer, unique=False, nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    orders = db.Column(JsonEcodedDict)

    def __repr__(self):
        return'<CustomerOrder %r>' % self.invoice


class Addproduct(db.Model):
    __seachbale__ = ['name','desc']
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    price = db.Column(db.Numeric(10,2), nullable=False)
    # discount = db.Column(db.Integer, default=0,nullable=True)
    stock = db.Column(db.Integer, nullable=False)
    colors = db.Column(db.Text, nullable=True)
    desc = db.Column(db.Text, nullable=False)
    size = db.Column(db.Text,nullable=False)
    pub_date = db.Column(db.DateTime, nullable=False,default=datetime.utcnow)

    category_id = db.Column(db.Integer, db.ForeignKey('category.id'),nullable=False)
    category = db.relationship('Category',backref=db.backref('categories', lazy=True))

    # brand_id = db.Column(db.Integer, db.ForeignKey('brand.id'),nullable=False)
    # brand = db.relationship('Brand',backref=db.backref('brands', lazy=True))

    image_1 = db.Column(db.String(150), nullable=False, default='image1.jpg')
    image_2 = db.Column(db.String(150), nullable=False, default='image2.jpg')
    image_3 = db.Column(db.String(150), nullable=False, default='image3.jpg')

    def __repr__(self):
        return '<Post %r>' % self.name

class Sell(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    customer_id = db.Column(db.Integer,db.ForeignKey('register.id'),nullable=False)
    price = db.Column(db.Numeric(10,2), nullable=False)
    desc = db.Column(db.Text, nullable=False)
    size = db.Column(db.Text,nullable=False)
    pub_date = db.Column(db.DateTime, nullable=False,default=datetime.utcnow)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'),nullable=False)
    # email = db.Column(db.String(80),nullable=False)
    # user = db.relationship('Register',backref=db.backref('registers',lazy=True))
    image_1 = db.Column(db.String(150), nullable=False, default='image1.jpg')
    image_2 = db.Column(db.String(150), nullable=False, default='image2.jpg')
    image_3 = db.Column(db.String(150), nullable=False, default='image3.jpg')

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), unique=True, nullable=False)

    def __repr__(self):
        return '<Category %r>' % self.name

# class Coupon(db.Model):
#     id = db.Column(db.Integer,primary_key=True)
#     # name = db.Column(db.String(30),nullable=False)
#     # email = db.Column(db.String(30),nullable=False)
#     userid = db.Column(db.Integer,db.ForeignKey('register.id'),nullable=False)
#     material = db.Column(db.Text,nullable=False)
#     couponcode = db.Column(db.String(30),nullable=False,unique=True)
#     category_id = db.Column(db.Integer, db.ForeignKey('category.id'),nullable=False)
#     discount = db.Column(db.Integer,nullable=False) 
#     image_1 = db.Column(db.String(150), nullable=False, default='image1.jpg')


db.create_all()




    


