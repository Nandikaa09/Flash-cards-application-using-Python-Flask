# from flask.wtf import Form, TextField, TextAreaField, SubmitField, validators, ValidationError
from wtforms import Form, StringField, FloatField,IntegerField, TextAreaField, PasswordField,SubmitField,validators, ValidationError
from flask_wtf.file import FileRequired,FileAllowed, FileField
from flask_wtf import FlaskForm

class ContactForm(Form):
  name = TextAreaField("Name",  [validators.DataRequired(message="Please enter your name.")])
  email = TextAreaField("Email",  [validators.DataRequired(message="Please enter your email address."), validators.Email(message="Please enter your email address.")])
  subject = TextAreaField("Subject",  [validators.DataRequired(message="Please enter a subject.")])
  message = TextAreaField("Message",  [validators.DataRequired(message="Please enter a message.")])
  submit = SubmitField("Send")