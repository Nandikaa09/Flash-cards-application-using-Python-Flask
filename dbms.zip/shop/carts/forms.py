from wtforms import Form, StringField, FloatField,IntegerField, TextAreaField, PasswordField,SubmitField,validators, ValidationError
from flask_wtf.file import FileRequired,FileAllowed, FileField
from flask_wtf import FlaskForm

class CoupForm(Form):
    coupon = StringField('Name')
